#include "test_fail.hpp"

void test() {
  check_incomplete(select(p.id));
}

