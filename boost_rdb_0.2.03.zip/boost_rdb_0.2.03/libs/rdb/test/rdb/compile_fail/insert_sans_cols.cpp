#include "test_fail.hpp"

void test() {
  check_incomplete(insert_into(p));
}

