//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2007.
//  Use, modification, and distribution are subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#include <cmath>
#include <iostream>
#include <ostream>

#include "test.hpp"

using namespace boost::sql_cli::test;

struct record
{
    record( signed char sc1,
            unsigned char uc1,
            signed short ss1,
            unsigned short us1,
            signed long sl1,
            unsigned long ul1,
            signed long long sll1,
            unsigned long long ull1) :
            sc(sc1),
            uc(uc1),
            ss(ss1), 
            us(us1),
            sl(sl1),
            ul(ul1),
            sll(sll1),
            ull(ull1)
    {
    }

    signed char sc;
    unsigned char uc;
    signed short ss;
    unsigned short us;
    signed long sl;
    unsigned long ul;
    signed long long sll;
    unsigned long long ull;
};


int test1(boost::sql_cli::connection & conn)
{
    table t(conn, "t",
            "sc tinyint,    uc unsigned tinyint, "
            "ss smallint,   us unsigned smallint, "
            "sl int,        ul unsigned int, "
            "sll bigint,    ull unsigned bigint");

    typedef std::vector<record> data_vect;
    data_vect data;
    for ( int i = 0; i < 10; ++i )
    {
        data.push_back(record(
                static_cast<signed char>( i - 64 ),
                static_cast<unsigned char>( i + 64 ),
                static_cast<signed short>( i - 8192 ),
                static_cast<unsigned short>( i + 8192 ),
                static_cast<signed long>( i - 1048576l ),
                static_cast<unsigned long>( i + 1048576ul ),
                static_cast<signed long long>( i - 134217728ll ),
                static_cast<unsigned long long>( i + 134217728ull ) ));
    }

    signed char sc;
    unsigned char uc;
    signed short ss;
    unsigned short us;
    signed long sl;
    unsigned long ul;
    signed long long sll;
    unsigned long long ull;
    boost::sql_cli::statement st(conn);
    st.prepare("insert into t ( sc, uc, ss, us, sl, ul, sll, ull) "
            "values ( ?, ?, ?, ?, ?, ?, ?, ? )",
            sc,
            uc,
            ss,
            us,
            sl,
            ul,
            sll,
            ull);
    for ( data_vect::iterator dvi = data.begin(); dvi != data.end(); ++dvi )
    {
        sc = dvi->sc;
        uc = dvi->uc;
        ss = dvi->ss;
        us = dvi->us;
        sl = dvi->sl;
        ul = dvi->ul;
        sll = dvi->sll;
        ull = dvi->ull;
        st.exec();
    }
    conn.commit();

    st.exec("select * from t");
    boost::sql_cli::result_set rs(st);
    data_vect::iterator dvi = data.begin();
    for ( boost::sql_cli::result_set::iterator rsi = rs.begin(); 
            rsi != rs.end(); ++rsi )
    {
        if ( dvi == data.end() )
            throw std::runtime_error("Too many rows retrieved");
        BOOST_CHECK( (*rsi)["sc"].get<signed char>() == dvi->sc );
        BOOST_CHECK( (*rsi)["uc"].get<unsigned char>() == dvi->uc );
        BOOST_CHECK( (*rsi)["ss"].get<signed short>() == dvi->ss );
        BOOST_CHECK( (*rsi)["us"].get<unsigned short>() == dvi->us );
        BOOST_CHECK( (*rsi)["sl"].get<signed long>() == dvi->sl );
        BOOST_CHECK( (*rsi)["ul"].get<unsigned long>() == dvi->ul );
        BOOST_CHECK( (*rsi)["sll"].get<signed long long>() == dvi->sll );
        BOOST_CHECK( (*rsi)["ull"].get<unsigned long long>() == dvi->ull );
        ++dvi;
    }

    return 0;
}

int test_main( int, char *[] )
{
    test_suite ts;
    ts.subscribe(test1);
    return ts.run();
}
