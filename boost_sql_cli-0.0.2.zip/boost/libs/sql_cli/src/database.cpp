//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006 - 2007. 
//  Use, modification, and distribution are subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#include <boost/optional.hpp>
#include <boost/detail/workaround.hpp>

#define BOOST_SQL_CLI_SOURCE

#include <boost/sql_cli/null_value.hpp>
#include <boost/sql_cli/detail/database.hpp>

#if BOOST_WORKAROUND(__BORLANDC__, <= 0x564)
#   pragma hdrstop
#endif

#include <boost/sql_cli/detail/dispatch.hpp>
#include <boost/sql_cli/odbc/odbc_connection.hpp>

#if BOOST_WORKAROUND(__BORLANDC__, BOOST_TESTED_AT(0x582))
#   pragma warn -8080
#endif

#include <boost/sql_cli/odbc/odbc_statement.hpp>
#include <boost/sql_cli/odbc/odbc_field.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{

database::database(std::string const & name) : idx(find_index(name))
{
}

struct database::connection_creator
{
    typedef std::auto_ptr<connection_base> result_type;

    template <typename BackendT>
    result_type operator() (BackendT const & b)
    {
        return b.create_connection();
    }
};

std::auto_ptr<connection_base> database::create_connection() const
{
    return dispatch(idx, connection_creator());
}

template <typename ValueT>
struct database::param_binder
{
    typedef void result_type;

    param_binder(statement_base * s, int n, ValueT & v) : stmt(s), num(n), 
            val(&v)
    {
    }

    template <typename BackendT>
    result_type operator() (BackendT & b)
    {
        return b.bind_param(stmt, num, *val);
    }

    statement_base * stmt;
    int num;
    ValueT * val;
};

template <typename ValueT> 
void database::bind_param(statement_base * s, int n, ValueT & v)
{
    dispatch(idx, param_binder<ValueT>(s, n, v));
}

#define BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(VALUE_T) \
		template void BOOST_SQL_CLI_DECL database::bind_param ( \
                statement_base *, int, VALUE_T &); \
		template void BOOST_SQL_CLI_DECL database::bind_param ( \
                statement_base *, int, boost::optional<VALUE_T> &); \
		template void BOOST_SQL_CLI_DECL database::bind_param ( \
                statement_base *, int, null_value<VALUE_T> & v)

BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(signed char);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(unsigned char);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(short);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(unsigned short);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(long);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(unsigned long);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(long long);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(unsigned long long);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(float);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(double);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(std::string);
BOOST_SQL_CLI_DETAIL_DATABASE_BIND_PARAM_INSTANTIATE(std::wstring);

template <typename ValueT> 
struct database::value_getter
{
    typedef ValueT value_type;
    typedef value_type result_type;

    value_getter(field_base * f) : fld(f)
    {
    }

    template <typename BackendT>
    result_type operator() (BackendT & b) const
    {
        return b.get<value_type>(fld);
    }

    field_base * fld;
};

template <typename ValueT> 
ValueT database::get(field_base * f) const
{
    return dispatch(idx, value_getter<ValueT>(f));
}

#define BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(VALUE_T) \
        template VALUE_T BOOST_SQL_CLI_DECL database::get<VALUE_T> ( \
                field_base *) const; \
        template boost::optional<VALUE_T> BOOST_SQL_CLI_DECL \
                database::get<boost::optional<VALUE_T> >(field_base *) const; \
        template null_value<VALUE_T> BOOST_SQL_CLI_DECL \
                database::get<null_value<VALUE_T> >(field_base *) const

BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(signed char);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(unsigned char);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(short);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(unsigned short);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(long);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(unsigned long);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(long long);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(unsigned long long);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(float);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(double);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(std::string);
BOOST_SQL_CLI_DETAIL_DATABASE_GET_INSTANTIATE(std::wstring);

} // namespace detail
} // namespace sql_cli
} // namespace boost



