//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#include <boost/detail/workaround.hpp>

#if BOOST_WORKAROUND(__BORLANDC__, <= 0x564)
#   pragma hdrstop
#endif

#include <boost/sql_cli/detail/dispatch.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{

backend_tuple backends;

} // namespace detail
} // namespace sql_cli
} // namespace boost
