//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#include <boost/sql_cli/detail/backend_traits.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{

template <>
std::string const backend_traits<odbc_tag>::base_type::name = "ODBC";

} // namespace detail
} // namespace sql_cli
} // namespace boost

