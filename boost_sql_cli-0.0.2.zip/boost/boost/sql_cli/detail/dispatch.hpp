//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#if ! defined(BOOST_SQL_CLI_DETAIL_DISPATCH_HPP)
#define BOOST_SQL_CLI_DETAIL_DISPATCH_HPP

#include <cassert>
#include <sstream>
#include <string>

#include <boost/tuple/tuple.hpp>
#include <boost/detail/workaround.hpp>

#include <boost/sql_cli/error.hpp>
#include <boost/sql_cli/detail/backend_traits.hpp>
#include <boost/sql_cli/detail/backend.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{
typedef boost::tuple<backend<odbc_tag> > backend_tuple;

extern backend_tuple backends;

template <int indexV>
struct dispatcher
{
    template <typename FunctionT>
    typename FunctionT::result_type operator() (int i, FunctionT f)
    {
        if ( i == indexV )
        {
            return f(backends.get<indexV>());
        }
        else
            return dispatcher<indexV+1>()(i, f);
    }
};

template <>
struct dispatcher<boost::tuples::length<backend_tuple>::value>
{
    template <typename FunctionT>
    typename FunctionT::result_type operator() (int, FunctionT)
    {
        // This is actually unreachable, but the compiler cannot know
        throw error("unrecoverable dispatch error");
    }
};

template <typename FunctionT>
inline typename FunctionT::result_type dispatch(int i, FunctionT f)
{
    assert(i < boost::tuples::length<backend_tuple>::value);

    return dispatcher<0>()(i, f);
}

template <int indexV>
struct index_finder
{
    int operator() (std::string const & n)
    {
        if ( backend_traits<typename boost::tuples::element<indexV, 
            backend_tuple>::type::server_type>::name == n )
        {
            return indexV;
        }
        else
            return index_finder<indexV+1>()(n);
    }
};

template <>
struct index_finder<boost::tuples::length<backend_tuple>::value>
{
    int operator() (std::string const & n)
    {
        throw error(n + ": database not supported");
    }
};

inline int find_index(std::string const & k)
{
    return index_finder<0>()(k);
}

} // namespace detail
} // namespace sql_cli
} // namespace boost

#endif // ! defined(BOOST_SQL_CLI_DETAIL_DISPATCH_HPP)
