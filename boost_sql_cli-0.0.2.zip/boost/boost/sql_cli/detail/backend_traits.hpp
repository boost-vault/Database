//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006 - 2007. 
//  Use, modification, and distribution are subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#if ! defined(BOOST_SQL_CLI_DETAIL_BACKEND_TRAITS_HPP)
#define BOOST_SQL_CLI_DETAIL_BACKEND_TRAITS_HPP

#include <string>

#include <boost/mpl/vector.hpp>

namespace boost
{
namespace sql_cli
{
namespace odbc
{
class connection;
class statement;
class field;
} // namespace odbc

namespace detail
{

struct odbc_tag {};

template <typename ServerT>
struct backend_traits
{
    typedef void connection_type;
    typedef void statement_type;
    typedef void field_type;
};

template <typename ConnectionT, typename StatementT, typename FieldT>
struct backend_traits_base
{
    typedef ConnectionT connection_type;
    typedef StatementT statement_type;
    typedef FieldT field_type;

    typedef boost::mpl::vector <
            signed char, unsigned char, 
            short, unsigned short,
            long, unsigned long,
            long long, unsigned long long,
            float, double, 
            std::string, std::wstring> value_types;
    
    typedef backend_traits_base base_type;

    static std::string const name;
};

template <>
struct backend_traits<odbc_tag> : backend_traits_base<odbc::connection, 
    odbc::statement, odbc::field>
{
};

} // namespace detail
} // namespace sql_cli
} // namespace boost

#endif // ! defined(BOOST_SQL_CLI_DETAIL_BACKEND_TRAITS_HPP)
