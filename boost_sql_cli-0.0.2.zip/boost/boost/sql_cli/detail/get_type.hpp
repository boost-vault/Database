//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#if ! defined(BOOST_SQL_CLI_DETAIL_GET_TYPE_HPP)
#define BOOST_SQL_CLI_DETAIL_GET_TYPE_HPP

#include <boost/optional.hpp>

#include <boost/sql_cli/null_value.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{

template <typename ValueT>
struct get_type
{
    typedef ValueT type;
};

template <typename ValueT>
struct get_type<sql_cli::null_value<ValueT> >
{
    typedef typename sql_cli::null_value<ValueT>::type type;
};

template <typename ValueT>
struct get_type<boost::optional<ValueT> >
{
    typedef typename boost::optional<ValueT>::value_type type;
};

} //namespace detail
} // namespace sql_cli
} // namespace boost

#endif // ! defined(BOOST_SQL_CLI_DETAIL_GET_TYPE_HPP)
