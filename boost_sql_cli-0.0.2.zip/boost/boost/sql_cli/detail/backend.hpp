//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#if ! defined(BOOST_SQL_CLI_DETAIL_BACKEND_HPP)
#define BOOST_SQL_CLI_DETAIL_BACKEND_HPP

#include <memory>

#include <boost/sql_cli/detail/backend_traits.hpp>

namespace boost
{
namespace sql_cli
{
namespace detail
{
class connection_base;
class statement_base;
class field_base;

template <typename ServerT>
class backend
{
public:
    typedef ServerT server_type;
    typedef backend_traits<server_type> traits_type;

    std::auto_ptr<connection_base> create_connection() const
    {
        std::auto_ptr<connection_base> c (
                new typename traits_type::connection_type);
        return c;
    }

    template <typename ValueT> 
    void bind_param(statement_base * s, int n, ValueT & v)
    {
        static_cast<typename traits_type::statement_type *>(s)->bind_param(n,
                v);
    }

    template <typename ValueT>
    ValueT get(field_base * f) 
    { 
        return static_cast<typename traits_type::field_type *>(f) ->
                get<ValueT>();
    }
};

} // namespace detail
} // namespace sql_cli
} // namespace boost

#endif // ! defined(BOOST_SQL_CLI_DETAIL_BACKEND_HPP)
