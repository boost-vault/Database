//  Boost.SqlCli library ----------------------------------------------------//

//  Copyright Nicola Musatti 2006. Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/sql_cli for library home page. ------------//

#if ! defined(BOOST_SQL_CLI_DETAIL_DATABASE_HPP)
#define BOOST_SQL_CLI_DETAIL_DATABASE_HPP

#include <memory>
#include <string>

#include <boost/sql_cli/detail/config.hpp>

// this must occur after all of the includes and before any code appears:
#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_PREFIX
#endif

namespace boost
{
namespace sql_cli
{
namespace detail
{
class connection_base;
class statement_base;
class field_base;

class BOOST_SQL_CLI_DECL database
{
public:
    database(std::string const & name);

    std::auto_ptr<connection_base> create_connection() const;

    template <typename ValueT> 
    void bind_param(statement_base * s, int n, ValueT & v);

    template <typename ValueT> 
    ValueT get(field_base * f) const;

private:
    struct connection_creator;

    template <typename ValueT>
    struct param_binder;

    template <typename ValueT> 
    struct value_getter;

    int idx;
};

} // namespace detail
} // namespace sql_cli
} // namespace boost

// the suffix header occurs after all of our code:
#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_SUFFIX
#endif

#endif // ! defined(BOOST_SQL_CLI_DETAIL_DATABASE_HPP)
