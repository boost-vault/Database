#include "test_fail.hpp"

void test() {
  insert_into(p).values(1);
}

