#include <boost/rdb/sql.hpp>
#include "../../test/test.cpp"

//#include <boost/preprocessor/iteration/iterate.hpp>
//#include <boost/preprocessor/repetition.hpp>

//#define TEST2(n, x, y) x##n y##n
//#define SPLIT2(a, b) a, b
//#define BOOST_PP_RDB_CONCEPT_CHECK(z, n, t) \
//  BOOST_CONCEPT_CHECK(BOOST_PP_TUPLE_ELEM(2, 0, t)<BOOST_PP_TUPLE_ELEM(2, 1, t) ## n>);
//BOOST_PP_REPEAT(3, BOOST_PP_RDB_CONCEPT_CHECK, (ColumnContainer, Col))
